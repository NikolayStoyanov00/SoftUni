﻿using System;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] carParams = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            double carFuelQuantity = double.Parse(carParams[1]);
            double carFuelConsumptionPerKm = double.Parse(carParams[2]);

            IVehicle car = new Car(carFuelQuantity, carFuelConsumptionPerKm);

            string[] truckParams = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            double truckFuelQuantity = double.Parse(truckParams[1]);
            double truckFuelConsumptionPerKm = double.Parse(truckParams[2]);

            IVehicle truck = new Truck(truckFuelQuantity, truckFuelConsumptionPerKm);

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (command[0] == "Drive")
                {
                    if (command[1] == "Car")
                    {
                        car.Drive(double.Parse(command[2]));
                    }
                    else if (command[1] == "Truck")
                    {
                        truck.Drive(double.Parse(command[2]));
                    }
                }

                else if (command[0] == "Refuel")
                {
                    if (command[1] == "Car")
                    {
                        car.Refuel(double.Parse(command[2]));
                    }
                    else if (command[1] == "Truck")
                    {
                        truck.Refuel(double.Parse(command[2]));
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
