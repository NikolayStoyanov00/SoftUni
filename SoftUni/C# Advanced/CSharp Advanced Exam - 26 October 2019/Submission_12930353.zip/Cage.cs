﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rabbits
{
    public class Cage
    {
        private List<Rabbit> data;

        public string Name { get; set; }

        public int Capacity { get; set; }

        public int Count => data.Count;

        public Cage(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;

            data = new List<Rabbit>();
        }

        public void Add(Rabbit rabbit)
        {
            if (data.Count < Capacity)
            {
                data.Add(rabbit);
            }
        }

        public bool RemoveRabbit(string name)
        {
            foreach (Rabbit rabbit in data)
            {
                if (rabbit.Name == name)
                {
                    data.Remove(rabbit);
                    return true;
                }
            }
            return false;
        }

        public void RemoveSpecies(string species)
        {
            foreach (Rabbit rabbit in data)
            {
                if (rabbit.Species == species)
                {
                    data.Remove(rabbit);
                }
            }
        }

        public Rabbit SellRabbit(string name)
        {
            for (int rabbitIndex = 0; rabbitIndex < data.Count; rabbitIndex++)
            {
                if (data[rabbitIndex].Name == name)
                {
                    data[rabbitIndex].Available = false;
                    return data[rabbitIndex];
                }
            }
            return null;
        }

        public Rabbit[] SellRabbitsBySpecies(string species)
        {
            Rabbit[] rabbits = new Rabbit[data.Count];

            for (int i = 0; i < data.Count; i++)
            {
                if (data[i].Species == species)
                {
                    data[i].Available = false;
                    rabbits[i] = data[i];
                }
            }

            rabbits = rabbits.Where(x => x != null).ToArray();
            return rabbits.ToArray();
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Rabbits available at {Name}");
            foreach (Rabbit rabbit in data)
            {
                if (rabbit.Available == true)
                {
                    sb.AppendLine(rabbit.ToString());
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
