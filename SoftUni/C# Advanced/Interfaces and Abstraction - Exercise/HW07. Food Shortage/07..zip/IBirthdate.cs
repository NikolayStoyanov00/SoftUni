﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Food_Shortage
{
    interface IBirthdate
    {
        public string Birthdate { get; set; }
    }
}
