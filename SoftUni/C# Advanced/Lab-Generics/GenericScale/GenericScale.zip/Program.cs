﻿using System;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
