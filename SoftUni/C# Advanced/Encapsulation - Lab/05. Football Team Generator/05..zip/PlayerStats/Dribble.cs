﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Football_Team_Generator.PlayerStats
{
    public class Dribble
    {
        public int Stat { get; set; }

        public Dribble(int stat)
        {
            this.Stat = stat;
        }
    }
}
