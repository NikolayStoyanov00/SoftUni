﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Football_Team_Generator.PlayerStats
{
    public class Passing
    {
        public int Stat { get; set; }

        public Passing(int stat)
        {
            this.Stat = stat;
        }
    }
}
