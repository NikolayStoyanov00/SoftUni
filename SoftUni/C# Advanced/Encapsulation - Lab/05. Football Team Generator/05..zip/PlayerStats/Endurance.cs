﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Football_Team_Generator.PlayerStats
{
    public class Endurance
    {
        public int Stat { get; set; }

        public Endurance(int stat)
        {
            this.Stat = stat;
        }
    }
}
