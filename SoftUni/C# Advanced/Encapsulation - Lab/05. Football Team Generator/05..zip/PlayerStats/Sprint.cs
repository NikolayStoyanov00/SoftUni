﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Football_Team_Generator.PlayerStats
{
    public class Sprint
    {
        public int Stat { get; set; }

        public Sprint (int stat)
        {
            this.Stat = stat;
        }
    }
}
